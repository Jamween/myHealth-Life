# myHealth-Life
Repository for Final Mobile application development project 2nd Year
API's Used 
Weather: https://openweathermap.org/api
Calorie Counter: https://calorieninjas.com/api
Activity Counter: https://api-ninjas.com/api/caloriesburned
/
